package com.anncode.offersandcoupons.View

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import com.anncode.offersandcoupons.Model.Coupon
import com.anncode.offersandcoupons.R

class MainActivity : AppCompatActivity() {

    private var rvCoupons: RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        //VIEW
        rvCoupons = findViewById(R.id.rvCoupons) //UI
        rvCoupons?.layoutManager = LinearLayoutManager(this)
        val coupons = ArrayList<Coupon>()
        //VIEW





    }

}
