package com.anncode.offersandcoupons.Model

interface CouponRepository {
    fun getCouponsAPI()
}